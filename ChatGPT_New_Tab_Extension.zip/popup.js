document.getElementById('saveBtn').addEventListener('click', function() {
  const url = document.getElementById('urlInput').value;
  if (url) {
    // URL'yi Chrome'un storage alanında saklıyoruz
    chrome.storage.sync.set({ newTabURL: url }, function() {
      alert('URL saved! Now, the new tab will redirect to: ' + url);
    });
  } else {
    alert('Please enter a URL.');
  }
});

// Eğer daha önce bir URL kaydedildiyse, input alanına yerleştiriyoruz
chrome.storage.sync.get('newTabURL', function(data) {
  if (data.newTabURL) {
    document.getElementById('urlInput').value = data.newTabURL;
  }
});